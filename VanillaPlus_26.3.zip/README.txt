Vanilla Plus (built for Minecraft Java 26.3, resource pack format 97.1)
Install: put the zip (unzipped NOT needed) in .minecraft/resourcepacks, enable in Options > Resource Packs.
Changes: ~1,200 block textures (tile-safe sharpening, richer colour, fine pixel grain), ~830 item textures
(crisper edges, richer colour), ~370 HUD/menu sprites (slightly crisper). Animated textures, mobs, sky left vanilla.
Personal testing build derived from vanilla textures - not for public redistribution.
